#pragma once
#include "../SceneManagment/Scene.h"
using namespace ge;
Scene::Scene() : is_paused(false), is_end(false) {}
