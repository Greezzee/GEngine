#include "../SceneManagment/Scene.h"
Scene::Scene() : is_paused(false), is_end(false) {}
